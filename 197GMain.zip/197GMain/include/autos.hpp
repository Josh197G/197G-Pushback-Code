#pragma once


extern void TopGoalQUALS();
extern void BottomGoalQUALS();
extern void ElimsLow();
extern void ElimsHigh();
extern void Skills();



