#pragma once
#include "main.h"
#include "lemlib/api.hpp" // IWYU pragma: keep
#include "pros/misc.h"
#include "pros/misc.hpp"
#include "subsystems.hpp"//Our motors sensors and electronics
#include "autos.hpp"



/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */
void initialize() {
    pros::lcd::initialize(); // initialize brain screen
    chassis.calibrate(); // calibrate sensors

    // the default rate is 50. however, if you need to change the rate, you
    // can do the following.
    // lemlib::bufferedStdout().setRate(...);
    // If you use bluetooth or a wired connection, you will want to have a rate of 10ms

    // for more information on how the formatting for the loggers
    // works, refer to the fmtlib docs

    // thread to for brain screen and position logging
    pros::Task screenTask([&]() {
        while (true) {
            // print robot location to the brain screen
            pros::lcd::print(0, "X: %f", chassis.getPose().x); // x
            pros::lcd::print(1, "Y: %f", chassis.getPose().y); // y
            pros::lcd::print(2, "Theta: %f", chassis.getPose().theta); // heading
            // log position telemetry
            // lemlib::telemetrySink()->info("Chassis pose: {}", chassis.getPose());
            // delay to save resources
            pros::delay(50);
        }
    });
}

/**
 * Runs while the robot is disabled
 */
void disabled() {}

/**
 * runs after initialize if the robot is connected to field control
 */
void competition_initialize() {}

// get a path used for pure pursuit
// this needs to be put outside a function
ASSET(example_txt); // '.' replaced with "_" to make c++ happy

/**
 * Runs during auto
 *
 * This is an example autonomous routine which demonstrates a lot of the features LemLib has to offer
 */

void autonomous() {
    // set chassis pose
    chassis.setPose(0, 0, 0);

TopGoalQUALS();
//Skills();
//ElimsHigh();


}



bool WingTrue;
bool LoaderTrue;
bool ParkingValue;
bool RollerReal;
int RollerDirection = 127;

enum class AllianceColor {
    RED,
    BLUE
};

AllianceColor teamColor = AllianceColor::RED; //change as needed

/**
 * Runs in driver control
 */
void opcontrol() {
    // controller
    // loop to continuously update motors
    pros::Controller controller(pros::E_CONTROLLER_MASTER);
    while (true) {
        // get joystick positions
        int leftY = controller.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y);
        int rightX = controller.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_X);
        // move the chassis with curvature drive
        chassis.arcade(leftY, rightX);




if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_Y)){

  if(RollerReal == true){
    RollerDirection = -127;
    RollerReal = false;
  }
  else if(RollerReal == false){
    RollerDirection = 127;
    RollerReal = true;
  }
controller.rumble(".");
}

if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_L1) ) {
    
  BottomIntake.move(127);
  TopIntake.move(-127);

  
  Color.set_led_pwm(10);
  if(Color.get_hue() <= 359 && WingTrue == true && RollerDirection == 127){
    
    int redCount = 0, blueCount = 0, otherCount = 0;
    const int sampleCount = 10;
    int hueReadings[sampleCount]; // Array to store all readings

    for (int i = 0; i < sampleCount; i++) {
          int sample = Color.get_hue();
          hueReadings[i] = sample; // Store each reading
          
          // Define RED
          if (sample <= 18 || sample >= 340)
            redCount++;
          // Define BLUE
          else if (sample >= 19 && sample <= 339)
            blueCount++;
          else
            otherCount++;
          pros::delay(10); // minimum recommended wait time between samples
      }

        const char *votedColor;
        if (redCount > blueCount && redCount > otherCount)
          votedColor = "RED";
        else if (blueCount > redCount && blueCount > otherCount)
          votedColor = "BLUE";
        else
          votedColor = "OTHER";

        if ((teamColor == AllianceColor::RED && strcmp(votedColor, "BLUE") == 0) ||
            (teamColor == AllianceColor::BLUE && strcmp(votedColor, "RED") == 0)) {
              
            TopRoller.move(-127);
            pros::delay(200);
            TopRoller.move(127);


            }

  }


  TopRoller.move(RollerDirection);
  
} 
else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_L2)) {
  BottomIntake.move(-127);
  TopIntake.move(127);
  TopRoller.move(!RollerDirection);
} 
else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_DOWN)) {
  BottomIntake.move(-50);
 
} 
else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_UP)) {
  BottomIntake.move(50);
 
} 
else {
  BottomIntake.move(0);
  TopIntake.move(0);
  TopRoller.move(0);
} 



if (controller.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_B)) {
      if (WingTrue == false) {
        Wing.set_value(1);
        WingTrue = true;

      } else if (WingTrue == true) {

        Wing.set_value(0);
        WingTrue = false;

      }
    }
if (controller.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_A)) {
      if (LoaderTrue == false) {
        Loader.set_value(1);
        LoaderTrue = true;

      } else if (LoaderTrue == true) {
        Loader.set_value(0);
        LoaderTrue = false;
      }
    }
if (controller.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_X)) {



      if(ParkingValue == false){
        Park.set_value(true);
        ParkingValue = true;
      }
      else if(ParkingValue == true){
        Park.set_value(false);
        ParkingValue = false;

      }
      
           
       
        
    }



        // delay to save resources
        pros::delay(20);
    }
}
