#pragma once

#include "lemlib/api.hpp"
#include "pros/rtos.hpp"
#include "subsystems.hpp"



//Our Autonomous for the Top Middle goal during our Qualification matches
void TopGoalQUALS(){


        Loader.set_value(true);
      RegFull.move(127);
chassis.setPose(0, 0, 0);
//Chassis swings, so we can place our robot at an easy angle to set up, but we can still start at a good angle
 chassis.moveToPoint(0, 21, 900, {.minSpeed = 30});
//Chassis swings, so we can place our robot at an easy angle to set up, but we can still start at a good angle
chassis.swingToHeading(270,  DriveSide::LEFT, 700, {.minSpeed = 15});
chassis.moveToPoint(-19.75, 29, 900);
  pros::delay(700);

  chassis.moveToPoint(28, 29.5, 1500, {.forwards = false, .maxSpeed = 60});
 //   chassis.moveToPoint(26.5, 35, 300, {.forwards = true, .maxSpeed = 40});
  //    chassis.moveToPoint(26.5, 35, 300, {.forwards = false, .maxSpeed = 40});
//With this motion we move to the long goal, in order to score our four blocks.
pros::delay(800); 
        TopRoller.move(100);
        Loader.set_value(false);
        Wing.set_value(true);
        pros::delay(100);
        BottomIntake.move(-127); pros::delay(200); BottomIntake.move(127);
        
        TopRoller.move(80);
        pros::delay(2100);
 
chassis.moveToPoint(10, 29, 800);
      Wing.set_value(true);
      RegFull.move(0);
      BottomIntake.move(127);
//This is the start of our pathing to score on the middle goal
    chassis.swingToPoint(28, 4, DriveSide::LEFT, 700, {.minSpeed = 30});
    chassis.moveToPoint(28, 4, 3000, {.maxSpeed = 15});

     pros::delay(1500);

    chassis.turnToHeading(-45, 500, {.minSpeed = 5});

    chassis.moveToPoint(47, -8, 900, {.forwards = false, .maxSpeed = 50});
    pros::delay(700);
    TopIntake.move(-127); TopRoller.move(-50);  
////////////////////////////////
//  chassis.moveToPoint(-15, 0, 300);
 // chassis.moveToPoint(40, -15, 750, {.forwards = false});
 // chassis.waitUntilDone();
 //       TopIntake.move(-127);
 //       TopRoller.move(-80);  
  //      pros::delay(600);
 // chassis.moveToPose(0, 72, 270, 1300,
  //      {.lead = .15, .maxSpeed = 80});

}

//Our codes for Elimintations




void ElimsHigh(){
  pros::Task([&] {
    pros::delay(14900);
    Wing.set_value(true);
  });
chassis.setPose(0, 0, 0);
//Intial setup for (almost) entire autonomous
RegFull.move(127); 

//This movement picks up the blocks in the center of the Field
chassis.moveToPose(-12, 36, 315, 2500, {.lead = 0.4, .maxSpeed = 60});
//We release our matchloader and 
pros::delay(1500);
Loader.set_value(true);
chassis.turnToHeading(135, 750);
chassis.moveToPose(-45, -32, 180, 2500, {.lead = .6});
// pros::delay(500);
// chassis.moveToPoint(-45, 32, 2000, {.forwards = false, .minSpeed = 15});
// RegFull.move(-127); 
// pros::delay(200);
// Wing.set_value(false);
// RegFull.move(127);
// chassis.setPose(0,0,0);
// pros::delay(4000);
// RegFull.move(0);
// chassis.moveToPoint(-5, 8, 600);
// chassis.swingToHeading(180, DriveSide::LEFT,1000, {.maxSpeed = 90, .minSpeed = 5});
// Wing.set_value(true);
// chassis.moveToPoint(-8, -30, 5000, {.maxSpeed = 40});



}
void ElimsLow(){

chassis.setPose(0, 0, 0);
//Intial setup for (almost) entire autonomous
RegFull.move(127); 
Wing.set_value(true);
//This movement picks up the blocks in the center of the Field
chassis.moveToPose(12, 36, -315, 1500, {.lead = 0.4, .maxSpeed = 60});
//We release our matchloader and 
Loader.set_value(true);
chassis.turnToHeading(135, 750);
chassis.moveToPose(45, -32, -180, 2500, {.lead = .6});
pros::delay(500);
chassis.moveToPoint(45, 32, 2000, {.forwards = false, .minSpeed = 15});
RegFull.move(-127); 
pros::delay(200);
Wing.set_value(false);
RegFull.move(127);
chassis.setPose(0,0,0);
pros::delay(4000);
RegFull.move(0);
chassis.moveToPoint(5, 8, 600);
chassis.swingToHeading(-180, DriveSide::RIGHT,1000, {.maxSpeed = 90, .minSpeed = 5});
Wing.set_value(true);
chassis.moveToPoint(8, -30, 5000, {.maxSpeed = 40});



}
void Skills(){
chassis.setPose(0, 0, 0);
//Intial setup for (almost) entire autonomous
RegFull.move(127); 
Wing.set_value(true);
Loader.set_value(true);

chassis.moveToPoint(0, 32, 1500);
//Chassis swings, so we can place our robot at an easy angle to set up, but we can still start at a good angle
chassis.swingToHeading(270,  DriveSide::LEFT, 600);
//After at this angle, our robot travels in a boomerang motion to the matchloader
chassis.moveToPoint(-15, 32, 500);
pros::delay(500);
chassis.moveToPoint(0, 32, 500);

chassis.swingToHeading(170,  DriveSide::RIGHT, 600);

chassis.swingToHeading(270,  DriveSide::LEFT, 600);

chassis.moveToPoint(115, 3, 4000, {.forwards = false});
Loader.set_value(false);
chassis.swingToHeading(90, DriveSide::LEFT, 1000);

Wing.set_value(true);
pros::delay(2000);
chassis.setPose(0,0,0);
Wing.set_value(false);
Loader.set_value(true);
chassis.moveToPoint(0, 40, 1500);

  
//         Loader.set_value(true);
//         BottomIntake.move(127);
// chassis.setPose(0, 0, 0);
// //Chassis swings, so we can place our robot at an easy angle to set up, but we can still start at a good angle
//   chassis.swingToHeading(45,  DriveSide::RIGHT, 200);

// //After at this angle, our robot travels in a boomerang motion to the matchloader
//   chassis.moveToPose(-15, 32, 270, 2350,
//         {.lead = 0.7});
//   chassis.moveToPoint(-17, 32, 400);
//   pros::delay(600);

//   chassis.moveToPoint(26, 34, 900, {.forwards = false, .maxSpeed = 60});
// //With this motion we move to the long goal, in order to score our four blocks.
// pros::delay(600);
//         TopIntake.move(-127);
//         TopRoller.move(127);
       
//         pros::delay(1000);
//         chassis.setPose(0, 0, 0);
//         TopIntake.move(0);
//         TopRoller.move(0);
//         Loader.set_value(false);
// //This is the start of our pathing to score on the middle goal
//   chassis.moveToPoint(0, 10, 500, 
//   {.minSpeed = 30});
//   chassis.swingToPoint(-20, -5, DriveSide::LEFT, 500, 
//   {.minSpeed = 7});
//   chassis.moveToPoint(-20, -5, 500);
//   Loader.set_value(true);
//   chassis.turnToHeading(45, 200);
//   chassis.moveToPoint(-15, 0, 300);
//   chassis.moveToPoint(40, -15, 750, {.forwards = false});
//   chassis.waitUntilDone();
//         TopIntake.move(-127);
//         TopRoller.move(-80);  
//         pros::delay(600);

    




}